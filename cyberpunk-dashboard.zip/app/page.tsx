"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Brain, Database, Users, FolderGit2, Shield, User, Settings, LogOut, Menu, X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import Dashboard from "@/components/dashboard";
import AIAssistants from "@/components/ai-assistants";
import DataCatalog from "@/components/data-catalog";
import CollaborationHub from "@/components/collaboration-hub";
import Repositories from "@/components/repositories";
import Security from "@/components/security";
import Profile from "@/components/profile";
import SettingsPanel from "@/components/settings-panel";

export default function Home() {
  const [activePanel, setActivePanel] = useState("dashboard");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: <Database className="w-5 h-5" /> },
    { id: "ai-assistants", label: "AI Assistants", icon: <Brain className="w-5 h-5" /> },
    { id: "data-catalog", label: "Data Catalog", icon: <Database className="w-5 h-5" /> },
    { id: "collaboration", label: "Collaboration", icon: <Users className="w-5 h-5" /> },
    { id: "repositories", label: "Repositories", icon: <FolderGit2 className="w-5 h-5" /> },
    { id: "security", label: "Security", icon: <Shield className="w-5 h-5" /> },
    { id: "profile", label: "Profile", icon: <User className="w-5 h-5" /> },
    { id: "settings", label: "Settings", icon: <Settings className="w-5 h-5" /> },
  ];

  const renderPanel = () => {
    switch (activePanel) {
      case "dashboard":
        return <Dashboard />;
      case "ai-assistants":
        return <AIAssistants />;
      case "data-catalog":
        return <DataCatalog />;
      case "collaboration":
        return <CollaborationHub />;
      case "repositories":
        return <Repositories />;
      case "security":
        return <Security />;
      case "profile":
        return <Profile />;
      case "settings":
        return <SettingsPanel />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <main className="cyberpunk-bg min-h-screen flex flex-col overflow-hidden">
      {/* Header */}
      <header className="border-b border-cyan-900/30 backdrop-blur-sm bg-black/20 p-4 flex justify-between items-center">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="mr-2 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30"
          >
            {isSidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-yellow-400 bg-clip-text text-transparent">
            NEXUS<span className="text-yellow-400">OS</span>
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50 hover:text-cyan-300">
            <User className="mr-2 h-4 w-4" />
            Jane Doe
          </Button>
          <Button variant="ghost" size="icon" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.aside
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="w-64 border-r border-cyan-900/30 backdrop-blur-sm bg-black/20 overflow-y-auto"
            >
              <nav className="p-4">
                <ul className="space-y-2">
                  {menuItems.map((item) => (
                    <li key={item.id}>
                      <Button
                        variant={activePanel === item.id ? "default" : "ghost"}
                        className={`w-full justify-start ${
                          activePanel === item.id
                            ? "bg-cyan-900/50 text-yellow-400 hover:bg-cyan-900/70"
                            : "text-cyan-400 hover:bg-cyan-950/30 hover:text-cyan-300"
                        }`}
                        onClick={() => setActivePanel(item.id)}
                      >
                        {item.icon}
                        <span className="ml-2">{item.label}</span>
                      </Button>
                    </li>
                  ))}
                </ul>
              </nav>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Main Content */}
        <div className="flex-1 overflow-auto p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activePanel}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              {renderPanel()}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </main>
  );
}

