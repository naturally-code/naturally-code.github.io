"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Database, Search, Filter, Download, Upload, Eye, BarChart3, FileText, ImageIcon, FileCode, Clock, ChevronDown, ChevronUp, Plus } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function DataCatalog() {
  const [sortColumn, setSortColumn] = useState("name");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [searchQuery, setSearchQuery] = useState("");
  
  const datasets = [
    { 
      id: 1, 
      name: "Customer Analytics", 
      type: "CSV", 
      size: "1.2 GB", 
      updated: "2 hours ago", 
      tags: ["analytics", "customers"],
      icon: <FileText className="h-4 w-4 text-cyan-400" />
    },
    { 
      id: 2, 
      name: "Product Images", 
      type: "Images", 
      size: "3.7 GB", 
      updated: "1 day ago", 
      tags: ["products", "images"],
      icon: <ImageIcon className="h-4 w-4 text-purple-400" />
    },
    { 
      id: 3, 
      name: "Financial Reports", 
      type: "Excel", 
      size: "450 MB", 
      updated: "3 days ago", 
      tags: ["finance", "reports"],
      icon: <BarChart3 className="h-4 w-4 text-green-400" />
    },
    { 
      id: 4, 
      name: "User Behavior", 
      type: "JSON", 
      size: "820 MB", 
      updated: "5 days ago", 
      tags: ["users", "behavior"],
      icon: <FileCode className="h-4 w-4 text-yellow-400" />
    },
    { 
      id: 5, 
      name: "Marketing Campaign", 
      type: "CSV", 
      size: "340 MB", 
      updated: "1 week ago", 
      tags: ["marketing", "campaigns"],
      icon: <FileText className="h-4 w-4 text-cyan-400" />
    },
  ];

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
  };

  const filteredDatasets = datasets.filter(dataset => 
    dataset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    dataset.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    dataset.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const sortedDatasets = [...filteredDatasets].sort((a, b) => {
    if (sortColumn === "name") {
      return sortDirection === "asc" 
        ? a.name.localeCompare(b.name) 
        : b.name.localeCompare(a.name);
    } else if (sortColumn === "size") {
      const sizeA = parseFloat(a.size.split(" ")[0]);
      const sizeB = parseFloat(b.size.split(" ")[0]);
      return sortDirection === "asc" ? sizeA - sizeB : sizeB - sizeA;
    } else if (sortColumn === "updated") {
      // Simple string comparison for demo purposes
      return sortDirection === "asc" 
        ? a.updated.localeCompare(b.updated) 
        : b.updated.localeCompare(a.updated);
    }
    return 0;
  });

  const recentActivity = [
    { id: 1, action: "Downloaded", dataset: "Customer Analytics", user: "Alex", time: "10 minutes ago" },
    { id: 2, action: "Uploaded", dataset: "New Product Images", user: "Maria", time: "2 hours ago" },
    { id: 3, action: "Updated", dataset: "Financial Reports", user: "John", time: "5 hours ago" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">Data Catalog</h2>
        <Button className="bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
          <Upload className="mr-2 h-4 w-4" />
          Upload Dataset
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Stats Cards */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Total Datasets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <Database className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">1,243</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Storage Used</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <Database className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">3.2 TB</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Downloads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <Download className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">8,547</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <Eye className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">42</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Data Table */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm col-span-2">
          <CardHeader>
            <CardTitle className="text-cyan-300">Datasets</CardTitle>
            <CardDescription className="text-cyan-400/70">Browse and manage your datasets</CardDescription>
            
            <div className="flex flex-col sm:flex-row gap-4 mt-4">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-cyan-400/70" />
                <Input 
                  placeholder="Search datasets..." 
                  className="pl-8 bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300 placeholder:text-cyan-700"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Select defaultValue="all">
                  <SelectTrigger className="w-[130px] bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent className="bg-cyan-950 border-cyan-900 text-cyan-300">
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="csv">CSV</SelectItem>
                    <SelectItem value="images">Images</SelectItem>
                    <SelectItem value="excel">Excel</SelectItem>
                    <SelectItem value="json">JSON</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border border-cyan-900/50 overflow-hidden">
              <Table>
                <TableHeader className="bg-cyan-950/30">
                  <TableRow className="hover:bg-cyan-950/50 border-cyan-900/50">
                    <TableHead 
                      className="text-cyan-300 cursor-pointer"
                      onClick={() => handleSort("name")}
                    >
                      <div className="flex items-center">
                        Name
                        {sortColumn === "name" && (
                          sortDirection === "asc" ? 
                            <ChevronUp className="ml-1 h-4 w-4" /> : 
                            <ChevronDown className="ml-1 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="text-cyan-300">Type</TableHead>
                    <TableHead 
                      className="text-cyan-300 cursor-pointer"
                      onClick={() => handleSort("size")}
                    >
                      <div className="flex items-center">
                        Size
                        {sortColumn === "size" && (
                          sortDirection === "asc" ? 
                            <ChevronUp className="ml-1 h-4 w-4" /> : 
                            <ChevronDown className="ml-1 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead 
                      className="text-cyan-300 cursor-pointer"
                      onClick={() => handleSort("updated")}
                    >
                      <div className="flex items-center">
                        Updated
                        {sortColumn === "updated" && (
                          sortDirection === "asc" ? 
                            <ChevronUp className="ml-1 h-4 w-4" /> : 
                            <ChevronDown className="ml-1 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="text-cyan-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedDatasets.map((dataset) => (
                    <TableRow key={dataset.id} className="hover:bg-cyan-950/30 border-cyan-900/50">
                      <TableCell className="font-medium text-cyan-300">
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-cyan-900/30 flex items-center justify-center">
                            {dataset.icon}
                          </div>
                          {dataset.name}
                        </div>
                      </TableCell>
                      <TableCell className="text-cyan-400">{dataset.type}</TableCell>
                      <TableCell className="text-cyan-400">{dataset.size}</TableCell>
                      <TableCell className="text-cyan-400">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3 text-cyan-400/70" />
                          {dataset.updated}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                            <BarChart3 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="text-sm text-cyan-400">
              Showing <span className="text-yellow-400">{sortedDatasets.length}</span> of <span className="text-yellow-400">{datasets.length}</span> datasets
            </div>
            <Button variant="outline" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
              View All
            </Button>
          </CardFooter>
        </Card>

        {/* Recent Activity */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-cyan-300">Recent Activity</CardTitle>
            <CardDescription className="text-cyan-400/70">Latest data operations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3 p-2 rounded-md hover:bg-cyan-950/20 transition-colors">
                  <div className="h-8 w-8 rounded-full bg-cyan-900/30 flex items-center justify-center mt-1">
                    {activity.action === "Downloaded" ? (
                      <Download className="h-4 w-4 text-cyan-400" />
                    ) : activity.action === "Uploaded" ? (
                      <Upload className="h-4 w-4 text-green-400" />
                    ) : (
                      <FileText className="h-4 w-4 text-yellow-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-cyan-300">
                      <span className="font-medium text-yellow-400">{activity.user}</span> {activity.action.toLowerCase()} <span className="text-cyan-300">{activity.dataset}</span>
                    </p>
                    <p className="text-xs text-cyan-400/70 flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
              View All Activity
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Popular Tags */}
      <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-cyan-300">Popular Tags</CardTitle>
            <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
              <Plus className="h-4 w-4 mr-1" />
              Add Tag
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {["analytics", "customers", "products", "images", "finance", "reports", "users", "behavior", "marketing", "campaigns", "sales", "inventory", "research", "development", "testing"].map((tag) => (
              <Badge 
                key={tag} 
                className="bg-cyan-900/30 hover:bg-cyan-900/50 text-cyan-300 border border-cyan-800/50 cursor-pointer"
              >
                {tag}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

