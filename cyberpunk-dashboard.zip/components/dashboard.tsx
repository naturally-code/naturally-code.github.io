"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Brain, Database, Users, FolderGit2, Shield, BarChart3, Activity, Bell, Clock, Zap } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export default function Dashboard() {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  const dashboardCards = [
    { 
      id: "ai", 
      title: "AI Assistants", 
      description: "3 active models", 
      icon: <Brain className="h-8 w-8 text-yellow-400" />,
      color: "from-cyan-900/50 to-blue-900/50",
      stats: "87% accuracy"
    },
    { 
      id: "data", 
      title: "Data Catalog", 
      description: "1,243 datasets", 
      icon: <Database className="h-8 w-8 text-yellow-400" />,
      color: "from-cyan-900/50 to-purple-900/50",
      stats: "3.2TB stored"
    },
    { 
      id: "collab", 
      title: "Collaboration", 
      description: "7 active projects", 
      icon: <Users className="h-8 w-8 text-yellow-400" />,
      color: "from-cyan-900/50 to-green-900/50",
      stats: "12 team members"
    },
    { 
      id: "repos", 
      title: "Repositories", 
      description: "32 repositories", 
      icon: <FolderGit2 className="h-8 w-8 text-yellow-400" />,
      color: "from-cyan-900/50 to-yellow-900/50",
      stats: "Last commit: 2h ago"
    },
  ];

  const activityData = [
    { id: 1, user: "Alex", action: "deployed model", time: "2 minutes ago", icon: <Zap className="h-4 w-4 text-yellow-400" /> },
    { id: 2, user: "Maria", action: "updated dataset", time: "15 minutes ago", icon: <Database className="h-4 w-4 text-cyan-400" /> },
    { id: 3, user: "John", action: "created repository", time: "1 hour ago", icon: <FolderGit2 className="h-4 w-4 text-green-400" /> },
    { id: 4, user: "Sarah", action: "invited team member", time: "3 hours ago", icon: <Users className="h-4 w-4 text-purple-400" /> },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">Dashboard</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
            <Bell className="mr-2 h-4 w-4" />
            Notifications
          </Button>
          <Button variant="outline" size="sm" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
            <Clock className="mr-2 h-4 w-4" />
            History
          </Button>
        </div>
      </div>

      {/* Main Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {dashboardCards.map((card) => (
          <motion.div
            key={card.id}
            onHoverStart={() => setHoveredCard(card.id)}
            onHoverEnd={() => setHoveredCard(null)}
            whileHover={{ y: -5, scale: 1.02 }}
            transition={{ duration: 0.2 }}
          >
            <Card className={`border-cyan-900/50 bg-gradient-to-br ${card.color} backdrop-blur-sm overflow-hidden relative h-full`}>
              <motion.div
                className="absolute inset-0 bg-grid-pattern opacity-10"
                animate={{
                  backgroundPosition: hoveredCard === card.id ? ["0px 0px", "20px 20px"] : "0px 0px",
                }}
                transition={{ duration: 1, repeat: hoveredCard === card.id ? Infinity : 0 }}
              />
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  {card.icon}
                  <motion.div
                    className="h-8 w-8 rounded-full bg-cyan-900/30 flex items-center justify-center"
                    whileHover={{ rotate: 180 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Activity className="h-4 w-4 text-cyan-400" />
                  </motion.div>
                </div>
                <CardTitle className="text-cyan-300 mt-2">{card.title}</CardTitle>
                <CardDescription className="text-cyan-400/70">{card.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-cyan-400/70">
                    <span>Usage</span>
                    <span>67%</span>
                  </div>
                  <Progress value={67} className="h-1 bg-cyan-950" indicatorClassName="bg-gradient-to-r from-cyan-400 to-yellow-400" />
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <p className="text-xs text-yellow-400">{card.stats}</p>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Activity and Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Activity Feed */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm col-span-2">
          <CardHeader>
            <CardTitle className="text-cyan-300">Recent Activity</CardTitle>
            <CardDescription className="text-cyan-400/70">Latest actions across your workspace</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activityData.map((item) => (
                <div key={item.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-cyan-950/20 transition-colors">
                  <div className="h-8 w-8 rounded-full bg-cyan-900/30 flex items-center justify-center">
                    {item.icon}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-cyan-300">
                      <span className="font-medium text-yellow-400">{item.user}</span> {item.action}
                    </p>
                    <p className="text-xs text-cyan-400/70">{item.time}</p>
                  </div>
                  <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                    View
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
              View All Activity
            </Button>
          </CardFooter>
        </Card>

        {/* Stats Card */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-cyan-300">System Stats</CardTitle>
            <CardDescription className="text-cyan-400/70">Performance metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-cyan-400">CPU Usage</span>
                  <span className="text-sm text-yellow-400">42%</span>
                </div>
                <Progress value={42} className="h-1 bg-cyan-950" indicatorClassName="bg-gradient-to-r from-cyan-400 to-yellow-400" />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-cyan-400">Memory</span>
                  <span className="text-sm text-yellow-400">3.2/8 GB</span>
                </div>
                <Progress value={40} className="h-1 bg-cyan-950" indicatorClassName="bg-gradient-to-r from-cyan-400 to-yellow-400" />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-cyan-400">Network</span>
                  <span className="text-sm text-yellow-400">1.7 MB/s</span>
                </div>
                <Progress value={25} className="h-1 bg-cyan-950" indicatorClassName="bg-gradient-to-r from-cyan-400 to-yellow-400" />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-cyan-400">Storage</span>
                  <span className="text-sm text-yellow-400">1.2/5 TB</span>
                </div>
                <Progress value={24} className="h-1 bg-cyan-950" indicatorClassName="bg-gradient-to-r from-cyan-400 to-yellow-400" />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
              <BarChart3 className="mr-2 h-4 w-4" />
              Detailed Analytics
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

