"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Shield, Lock, Key, UserCheck, AlertTriangle, CheckCircle2, Clock, Eye, EyeOff, RefreshCw, Plus, Users, FileText, Settings, ChevronRight, Search } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Security() {
  const [showApiKey, setShowApiKey] = useState(false);
  
  const securityAlerts = [
    { 
      id: 1, 
      title: "Unusual login attempt", 
      description: "Multiple failed login attempts from IP 192.168.1.1", 
      severity: "High",
      time: "2 hours ago",
      status: "Active"
    },
    { 
      id: 2, 
      title: "API key exposed", 
      description: "API key was committed to a public repository", 
      severity: "Critical",
      time: "1 day ago",
      status: "Resolved"
    },
    { 
      id: 3, 
      title: "Outdated dependency", 
      description: "Security vulnerability in package xyz", 
      severity: "Medium",
      time: "3 days ago",
      status: "Active"
    },
  ];

  const accessLogs = [
    { 
      id: 1, 
      user: "Jane Doe", 
      action: "Logged in", 
      resource: "Dashboard", 
      ip: "192.168.1.100",
      time: "10 minutes ago",
      status: "Success"
    },
    { 
      id: 2, 
      user: "Alex Smith", 
      action: "Generated API key", 
      resource: "API Management", 
      ip: "192.168.1.101",
      time: "1 hour ago",
      status: "Success"
    },
    { 
      id: 3, 
      user: "Unknown", 
      action: "Failed login", 
      resource: "Login Page", 
      ip: "203.0.113.1",
      time: "2 hours ago",
      status: "Failed"
    },
    { 
      id: 4, 
      user: "Mike Kim", 
      action: "Accessed", 
      resource: "Customer Data", 
      ip: "192.168.1.102",
      time: "3 hours ago",
      status: "Success"
    },
    { 
      id: 5, 
      user: "Tom Wilson", 
      action: "Modified", 
      resource: "User Permissions", 
      ip: "192.168.1.103",
      time: "5 hours ago",
      status: "Success"
    },
  ];

  const apiKeys = [
    { 
      id: "api_key_1", 
      name: "Production API Key", 
      key: "sk_prod_a1b2c3d4e5f6g7h8i9j0", 
      created: "Oct 1, 2023",
      lastUsed: "2 hours ago",
      status: "Active"
    },
    { 
      id: "api_key_2", 
      name: "Development API Key", 
      key: "sk_dev_k1l2m3n4o5p6q7r8s9t0", 
      created: "Sep 15, 2023",
      lastUsed: "1 day ago",
      status: "Active"
    },
    { 
      id: "api_key_3", 
      name: "Testing API Key", 
      key: "sk_test_u1v2w3x4y5z6a7b8c9d0", 
      created: "Aug 30, 2023",
      lastUsed: "1 week ago",
      status: "Inactive"
    },
  ];

  const teamMembers = [
    { 
      id: 1, 
      name: "Jane Doe", 
      email: "jane@example.com", 
      role: "Admin",
      lastActive: "10 minutes ago",
      twoFactor: true
    },
    { 
      id: 2, 
      name: "Alex Smith", 
      email: "alex@example.com", 
      role: "Developer",
      lastActive: "1 hour ago",
      twoFactor: true
    },
    { 
      id: 3, 
      name: "Mike Kim", 
      email: "mike@example.com", 
      role: "Analyst",
      lastActive: "3 hours ago",
      twoFactor: false
    },
    { 
      id: 4, 
      name: "Tom Wilson", 
      email: "tom@example.com", 
      role: "Developer",
      lastActive: "1 day ago",
      twoFactor: true
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">Security</h2>
        <Button className="bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
          <Shield className="mr-2 h-4 w-4" />
          Security Audit
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Stats Cards */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Security Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <Shield className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">85/100</div>
            </div>
            <Progress value={85} className="h-1 bg-cyan-950" indicatorClassName="bg-gradient-to-r from-cyan-400 to-yellow-400" />
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Active Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">2</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">API Keys</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <Key className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">3</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Team Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <UserCheck className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">12</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security Alerts */}
      <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-cyan-300">Security Alerts</CardTitle>
              <CardDescription className="text-cyan-400/70">Recent security issues and vulnerabilities</CardDescription>
            </div>
            <Button variant="outline" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {securityAlerts.map((alert) => (
              <motion.div
                key={alert.id}
                whileHover={{ x: 3 }}
                className={`p-4 rounded-md border ${
                  alert.status === 'Active' ? 
                    alert.severity === 'Critical' ? 'border-red-900/50 bg-red-950/10' : 
                    alert.severity === 'High' ? 'border-orange-900/50 bg-orange-950/10' : 
                    'border-yellow-900/50 bg-yellow-950/10' 
                  : 'border-green-900/50 bg-green-950/10'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-start gap-3">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                      alert.status === 'Active' ? 
                        alert.severity === 'Critical' ? 'bg-red-900/30' : 
                        alert.severity === 'High' ? 'bg-orange-900/30' : 
                        'bg-yellow-900/30' 
                      : 'bg-green-900/30'
                    }`}>
                      {alert.status === 'Active' ? 
                        <AlertTriangle className="h-4 w-4 text-yellow-400" /> : 
                        <CheckCircle2 className="h-4 w-4 text-green-400" />
                      }
                    </div>
                    <div>
                      <h3 className="font-medium text-cyan-300">{alert.title}</h3>
                      <p className="text-sm text-cyan-400/70 mt-1">{alert.description}</p>
                    </div>
                  </div>
                  <Badge 
                    className={`
                      ${alert.status === 'Active' ? 
                        alert.severity === 'Critical' ? 'bg-red-900/50 text-red-300' : 
                        alert.severity === 'High' ? 'bg-orange-900/50 text-orange-300' : 
                        'bg-yellow-900/50 text-yellow-300' 
                      : 'bg-green-900/50 text-green-300'} 
                      border border-cyan-800/50
                    `}
                  >
                    {alert.status === 'Active' ? alert.severity : 'Resolved'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center mt-3">
                  <div className="text-xs text-cyan-400/70 flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {alert.time}
                  </div>
                  {alert.status === 'Active' && (
                    <Button variant="outline" size="sm" className="h-7 border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                      Resolve
                    </Button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
            View All Alerts
          </Button>
        </CardFooter>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* API Keys */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-cyan-300">API Keys</CardTitle>
                <CardDescription className="text-cyan-400/70">Manage your API keys</CardDescription>
              </div>
              <Button className="bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
                <Plus className="mr-2 h-4 w-4" />
                New Key
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {apiKeys.map((apiKey) => (
                <div key={apiKey.id} className="p-3 rounded-md border border-cyan-900/50 bg-cyan-950/20">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-cyan-300">{apiKey.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="font-mono text-xs bg-cyan-950/50 rounded px-2 py-1 text-cyan-400 flex items-center">
                          {showApiKey ? apiKey.key : apiKey.key.substring(0, 8) + "•".repeat(12)}
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-5 w-5 ml-1 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30"
                            onClick={() => setShowApiKey(!showApiKey)}
                          >
                            {showApiKey ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                          </Button>
                        </div>
                      </div>
                    </div>
                    <Badge 
                      className={`${apiKey.status === 'Active' ? 'bg-green-900/50 text-green-300' : 'bg-yellow-900/50 text-yellow-300'} border border-cyan-800/50`}
                    >
                      {apiKey.status}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center mt-3 text-xs text-cyan-400/70">
                    <div className="flex items-center gap-4">
                      <span>Created: {apiKey.created}</span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" /> Last used: {apiKey.lastUsed}
                      </span>
                    </div>
                    <Button variant="ghost" size="sm" className="h-7 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                      Revoke
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Team Members */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-cyan-300">Team Members</CardTitle>
                <CardDescription className="text-cyan-400/70">Manage user access and permissions</CardDescription>
              </div>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-cyan-400/70" />
                <Input 
                  placeholder="Search members..." 
                  className="pl-8 w-48 bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300 placeholder:text-cyan-700"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border border-cyan-900/50 overflow-hidden">
              <Table>
                <TableHeader className="bg-cyan-950/30">
                  <TableRow className="hover:bg-cyan-950/50 border-cyan-900/50">
                    <TableHead className="text-cyan-300">Name</TableHead>
                    <TableHead className="text-cyan-300">Role</TableHead>
                    <TableHead className="text-cyan-300">2FA</TableHead>
                    <TableHead className="text-cyan-300">Last Active</TableHead>
                    <TableHead className="text-cyan-300 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {teamMembers.map((member) => (
                    <TableRow key={member.id} className="hover:bg-cyan-950/30 border-cyan-900/50">
                      <TableCell className="font-medium text-cyan-300">
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-cyan-900/30 flex items-center justify-center">
                            {member.name.split(' ').map(n => n[0]).join('')}
                          </div>
                          <div>
                            <div>{member.name}</div>
                            <div className="text-xs text-cyan-400/70">{member.email}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-cyan-900/30 text-cyan-300 border border-cyan-800/50">
                          {member.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Switch 
                            checked={member.twoFactor} 
                            className="data-[state=checked]:bg-green-600"
                          />
                        </div>
                      </TableCell>
                      <TableCell className="text-cyan-400">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3 text-cyan-400/70" />
                          {member.lastActive}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-7 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="text-sm text-cyan-400">
              Showing <span className="text-yellow-400">{teamMembers.length}</span> of <span className="text-yellow-400">12</span> members
            </div>
            <Button variant="outline" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
              <Plus className="mr-2 h-4 w-4" />
              Invite Member
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Access Logs */}
      <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-cyan-300">Access Logs</CardTitle>
              <CardDescription className="text-cyan-400/70">Recent activity and authentication events</CardDescription>
            </div>
            <Tabs defaultValue="all" className="w-[400px]">
              <TabsList className="bg-cyan-950/30 border border-cyan-900/50">
                <TabsTrigger value="all" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                  All
                </TabsTrigger>
                <TabsTrigger value="success" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                  Success
                </TabsTrigger>
                <TabsTrigger value="failed" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                  Failed
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border border-cyan-900/50 overflow-hidden">
            <Table>
              <TableHeader className="bg-cyan-950/30">
                <TableRow className="hover:bg-cyan-950/50 border-cyan-900/50">
                  <TableHead className="text-cyan-300">User</TableHead>
                  <TableHead className="text-cyan-300">Action</TableHead>
                  <TableHead className="text-cyan-300">Resource</TableHead>
                  <TableHead className="text-cyan-300">IP Address</TableHead>
                  <TableHead className="text-cyan-300">Time</TableHead>
                  <TableHead className="text-cyan-300">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accessLogs.map((log) => (
                  <TableRow key={log.id} className="hover:bg-cyan-950/30 border-cyan-900/50">
                    <TableCell className="font-medium text-cyan-300">{log.user}</TableCell>
                    <TableCell className="text-cyan-400">{log.action}</TableCell>
                    <TableCell className="text-cyan-400">{log.resource}</TableCell>
                    <TableCell className="font-mono text-xs text-cyan-400">{log.ip}</TableCell>
                    <TableCell className="text-cyan-400">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3 text-cyan-400/70" />
                        {log.time}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        className={`${log.status === 'Success' ? 'bg-green-900/50 text-green-300' : 'bg-red-900/50 text-red-300'} border border-cyan-800/50`}
                      >
                        {log.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-cyan-400">
            Showing <span className="text-yellow-400">{accessLogs.length}</span> of <span className="text-yellow-400">100</span> logs
          </div>
          <Button variant="outline" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
            <FileText className="mr-2 h-4 w-4" />
            Export Logs
          </Button>
        </CardFooter>
      </Card>

      {/* Security Settings */}
      <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-cyan-300">Security Settings</CardTitle>
          <CardDescription className="text-cyan-400/70">Configure security options for your workspace</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-medium text-cyan-300">Two-Factor Authentication</h3>
                  <p className="text-xs text-cyan-400/70 mt-1">Require 2FA for all team members</p>
                </div>
                <Switch defaultChecked className="data-[state=checked]:bg-cyan-600" />
              </div>
              
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-medium text-cyan-300">Session Timeout</h3>
                  <p className="text-xs text-cyan-400/70 mt-1">Automatically log out after inactivity</p>
                </div>
                <Switch defaultChecked className="data-[state=checked]:bg-cyan-600" />
              </div>
              
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-medium text-cyan-300">IP Restrictions</h3>
                  <p className="text-xs text-cyan-400/70 mt-1">Limit access to specific IP addresses</p>
                </div>
                <Switch className="data-[state=checked]:bg-cyan-600" />
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-medium text-cyan-300">Single Sign-On (SSO)</h3>
                  <p className="text-xs text-cyan-400/70 mt-1">Enable SSO with your identity provider</p>
                </div>
                <Switch defaultChecked className="data-[state=checked]:bg-cyan-600" />
              </div>
              
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-medium text-cyan-300">Audit Logging</h3>
                  <p className="text-xs text-cyan-400/70 mt-1">Enable detailed audit logs for all actions</p>
                </div>
                <Switch defaultChecked className="data-[state=checked]:bg-cyan-600" />
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
            <Settings className="mr-2 h-4 w-4" />
            Save Security Settings
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

