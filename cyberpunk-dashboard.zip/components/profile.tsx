"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { User, Mail, Lock, Bell, Shield, Save, Upload, Trash2, Edit, CheckCircle2, Clock, Calendar, MapPin, Briefcase, Github, Twitter, Linkedin } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  
  const userProfile = {
    name: "Jane Doe",
    email: "jane.doe@example.com",
    role: "Senior Data Scientist",
    bio: "Experienced data scientist with a focus on machine learning and AI. Passionate about solving complex problems and building innovative solutions.",
    location: "San Francisco, CA",
    joinDate: "January 2022",
    company: "TechCorp Inc.",
    avatar: "JD",
    skills: ["Machine Learning", "Python", "TensorFlow", "Data Analysis", "Neural Networks", "Computer Vision", "NLP"],
    social: {
      github: "github.com/janedoe",
      twitter: "twitter.com/janedoe",
      linkedin: "linkedin.com/in/janedoe"
    }
  };

  const recentActivity = [
    { id: 1, action: "Updated profile information", time: "2 hours ago" },
    { id: 2, action: "Deployed new AI model", time: "1 day ago" },
    { id: 3, action: "Created new repository", time: "3 days ago" },
    { id: 4, action: "Submitted pull request", time: "1 week ago" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">Profile</h2>
        <Button 
          variant={isEditing ? "default" : "outline"}
          className={isEditing ? 
            "bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white" : 
            "border-cyan-700 text-cyan-400 hover:bg-cyan-950/50"
          }
          onClick={() => setIsEditing(!isEditing)}
        >
          {isEditing ? (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </>
          ) : (
            <>
              <Edit className="mr-2 h-4 w-4" />
              Edit Profile
            </>
          )}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Overview */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <div className="flex flex-col items-center">
              <div className="relative">
                <Avatar className="h-24 w-24 border-4 border-cyan-900/50">
                  <AvatarFallback className="text-2xl bg-cyan-900/70 text-cyan-300">
                    {userProfile.avatar}
                  </AvatarFallback>
                </Avatar>
                {isEditing && (
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="absolute bottom-0 right-0 h-8 w-8 rounded-full border-cyan-700 bg-cyan-950/70 text-cyan-400 hover:bg-cyan-950/90"
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                )}
              </div>
              <CardTitle className="text-cyan-300 mt-4">{userProfile.name}</CardTitle>
              <CardDescription className="text-cyan-400/70">{userProfile.role}</CardDescription>
              
              <Badge className="mt-2 bg-cyan-900/30 text-cyan-300 border border-cyan-800/50">
                Active
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 mt-4">
              <div className="flex items-center gap-2 text-cyan-400">
                <Mail className="h-4 w-4 text-cyan-400/70" />
                <span>{userProfile.email}</span>
              </div>
              
              <div className="flex items-center gap-2 text-cyan-400">
                <MapPin className="h-4 w-4 text-cyan-400/70" />
                <span>{userProfile.location}</span>
              </div>
              
              <div className="flex items-center gap-2 text-cyan-400">
                <Briefcase className="h-4 w-4 text-cyan-400/70" />
                <span>{userProfile.company}</span>
              </div>
              
              <div className="flex items-center gap-2 text-cya

