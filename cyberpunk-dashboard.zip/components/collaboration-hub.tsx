"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Users, MessageSquare, Calendar, FileText, Clock, Plus, Send, Paperclip, Video, Phone, User, MoreHorizontal, ChevronRight, CheckCircle2, Circle, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function CollaborationHub() {
  const [activeChat, setActiveChat] = useState("team-alpha");
  
  const teams = [
    { 
      id: "team-alpha", 
      name: "Team Alpha", 
      lastMessage: "Let's review the latest model results", 
      time: "10m",
      unread: 3,
      members: ["JD", "AS", "MK", "TW"],
      online: true
    },
    { 
      id: "data-science", 
      name: "Data Science", 
      lastMessage: "The preprocessing pipeline is ready", 
      time: "1h",
      unread: 0,
      members: ["AS", "RJ", "BL"],
      online: true
    },
    { 
      id: "project-nexus", 
      name: "Project Nexus", 
      lastMessage: "Updated the documentation", 
      time: "3h",
      unread: 0,
      members: ["JD", "MK", "AS", "TW", "RJ"],
      online: false
    },
  ];

  const messages = [
    { id: 1, sender: "Alex Smith", content: "I've completed the initial analysis of the dataset.", time: "10:32 AM", avatar: "AS" },
    { id: 2, sender: "Jane Doe", content: "Great! Can you share the results with the team?", time: "10:35 AM", avatar: "JD" },
    { id: 3, sender: "Mike Kim", content: "I'm interested in seeing how the model performs on the test set.", time: "10:40 AM", avatar: "MK" },
    { id: 4, sender: "Alex Smith", content: "Sure, I'll prepare a summary and share it in our next meeting.", time: "10:42 AM", avatar: "AS" },
    { id: 5, sender: "Tom Wilson", content: "When is our next meeting scheduled?", time: "10:45 AM", avatar: "TW" },
    { id: 6, sender: "Jane Doe", content: "Tomorrow at 2 PM. I've sent calendar invites to everyone.", time: "10:47 AM", avatar: "JD" },
  ];

  const projects = [
    { 
      id: 1, 
      name: "AI Model Deployment", 
      progress: 75, 
      status: "In Progress",
      dueDate: "Oct 15, 2023",
      members: ["JD", "AS", "MK"],
      tasks: { completed: 15, total: 20 }
    },
    { 
      id: 2, 
      name: "Data Pipeline Optimization", 
      progress: 40, 
      status: "In Progress",
      dueDate: "Nov 5, 2023",
      members: ["TW", "AS", "RJ"],
      tasks: { completed: 8, total: 20 }
    },
    { 
      id: 3, 
      name: "Dashboard Development", 
      progress: 90, 
      status: "Review",
      dueDate: "Oct 10, 2023",
      members: ["JD", "MK", "BL"],
      tasks: { completed: 18, total: 20 }
    },
  ];

  const upcomingEvents = [
    { 
      id: 1, 
      title: "Team Standup", 
      time: "Today, 11:00 AM", 
      participants: 5,
      location: "Virtual"
    },
    { 
      id: 2, 
      title: "Project Review", 
      time: "Tomorrow, 2:00 PM", 
      participants: 8,
      location: "Conference Room A"
    },
    { 
      id: 3, 
      title: "Client Presentation", 
      time: "Oct 12, 10:00 AM", 
      participants: 4,
      location: "Virtual"
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">Collaboration Hub</h2>
        <div className="flex gap-2">
          <Button variant="outline" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
            <Calendar className="mr-2 h-4 w-4" />
            Schedule Meeting
          </Button>
          <Button className="bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
            <Plus className="mr-2 h-4 w-4" />
            New Project
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat Section */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm lg:col-span-2 flex flex-col h-[600px]">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-cyan-300">Team Chat</CardTitle>
                <CardDescription className="text-cyan-400/70">Collaborate with your team in real-time</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  <Phone className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  <Video className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex-1 flex gap-4 overflow-hidden p-0">
            {/* Chat List */}
            <div className="w-64 border-r border-cyan-900/30 p-4 overflow-y-auto">
              <Input 
                placeholder="Search chats..." 
                className="mb-4 bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300 placeholder:text-cyan-700"
              />
              <div className="space-y-2">
                {teams.map((team) => (
                  <motion.div
                    key={team.id}
                    whileHover={{ x: 3 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setActiveChat(team.id)}
                    className={`p-2 rounded-md cursor-pointer ${
                      activeChat === team.id ? 'bg-cyan-900/50' : 'hover:bg-cyan-950/30'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <div className="font-medium text-cyan-300">{team.name}</div>
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-cyan-400/70">{team.time}</span>
                        {team.unread > 0 && (
                          <div className="h-5 w-5 rounded-full bg-yellow-400 text-black text-xs flex items-center justify-center">
                            {team.unread}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-xs text-cyan-400/70 truncate">{team.lastMessage}</div>
                    <div className="flex items-center mt-1">
                      <div className="flex -space-x-2">
                        {team.members.slice(0, 3).map((member, i) => (
                          <Avatar key={i} className="h-5 w-5 border border-cyan-900">
                            <AvatarFallback className="text-[10px] bg-cyan-900/70 text-cyan-300">
                              {member}
                            </AvatarFallback>
                          </Avatar>
                        ))}
                        {team.members.length > 3 && (
                          <Avatar className="h-5 w-5 border border-cyan-900">
                            <AvatarFallback className="text-[10px] bg-cyan-900/70 text-cyan-300">
                              +{team.members.length - 3}
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                      <div className={`ml-2 h-2 w-2 rounded-full ${team.online ? 'bg-green-400' : 'bg-yellow-400'}`} />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            
            {/* Chat Messages */}
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className="flex gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-cyan-900/70 text-cyan-300">
                        {message.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium text-cyan-300">{message.sender}</span>
                        <span className="text-xs text-cyan-400/70">{message.time}</span>
                      </div>
                      <div className="bg-cyan-950/30 rounded-md p-3 text-cyan-300 border border-cyan-900/50">
                        {message.content}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-4 border-t border-cyan-900/30">
                <div className="flex gap-2">
                  <Button variant="outline" size="icon" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Input 
                    placeholder="Type your message..." 
                    className="flex-1 bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300 placeholder:text-cyan-700"
                  />
                  <Button className="bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Projects and Events */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm h-[600px] flex flex-col">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300">Workspace</CardTitle>
            <CardDescription className="text-cyan-400/70">Projects and upcoming events</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden p-0">
            <Tabs defaultValue="projects" className="h-full flex flex-col">
              <TabsList className="mx-4 bg-cyan-950/30 border border-cyan-900/50">
                <TabsTrigger value="projects" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                  Projects
                </TabsTrigger>
                <TabsTrigger value="events" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                  Events
                </TabsTrigger>
                <TabsTrigger value="files" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                  Files
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="projects" className="flex-1 overflow-y-auto p-4 space-y-4 m-0">
                {projects.map((project) => (
                  <motion.div
                    key={project.id}
                    whileHover={{ y: -2 }}
                    className="p-3 rounded-md border border-cyan-900/50 bg-cyan-950/20 hover:bg-cyan-950/30 transition-colors"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-cyan-300">{project.name}</h3>
                      <Badge 
                        className={`
                          ${project.status === 'In Progress' ? 'bg-cyan-900/50 text-cyan-300' : 
                            project.status === 'Review' ? 'bg-yellow-900/50 text-yellow-300' : 
                            'bg-green-900/50 text-green-300'} 
                          border border-cyan-800/50
                        `}
                      >
                        {project.status}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs text-cyan-400/70">
                        <span>Progress</span>
                        <span>{project.progress}%</span>
                      </div>
                      <Progress 
                        value={project.progress} 
                        className="h-1 bg-cyan-950" 
                        indicatorClassName="bg-gradient-to-r from-cyan-400 to-yellow-400" 
                      />
                    </div>
                    <div className="flex justify-between items-center mt-3">
                      <div className="flex -space-x-2">
                        {project.members.map((member, i) => (
                          <Avatar key={i} className="h-6 w-6 border border-cyan-900">
                            <AvatarFallback className="text-xs bg-cyan-900/70 text-cyan-300">
                              {member}
                            </AvatarFallback>
                          </Avatar>
                        ))}
                      </div>
                      <div className="text-xs text-cyan-400/70 flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        Due: {project.dueDate}
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-cyan-400/70">
                      Tasks: {project.tasks.completed}/{project.tasks.total} completed
                    </div>
                  </motion.div>
                ))}
                <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  <Plus className="mr-2 h-4 w-4" />
                  New Project
                </Button>
              </TabsContent>
              
              <TabsContent value="events" className="flex-1 overflow-y-auto p-4 space-y-4 m-0">
                {upcomingEvents.map((event) => (
                  <motion.div
                    key={event.id}
                    whileHover={{ y: -2 }}
                    className="p-3 rounded-md border border-cyan-900/50 bg-cyan-950/20 hover:bg-cyan-950/30 transition-colors"
                  >
                    <div className="flex justify-between items-start mb-1">
                      <h3 className="font-medium text-cyan-300">{event.title}</h3>
                      <Badge className="bg-cyan-900/50 text-cyan-300 border border-cyan-800/50">
                        {event.participants} attendees
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-cyan-400/70 mb-2">
                      <Calendar className="h-3 w-3" />
                      {event.time}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-cyan-400/70">
                      <Users className="h-3 w-3" />
                      {event.location}
                    </div>
                  </motion.div>
                ))}
                <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  <Calendar className="mr-2 h-4 w-4" />
                  View Calendar
                </Button>
              </TabsContent>
              
              <TabsContent value="files" className="flex-1 overflow-y-auto p-4 space-y-4 m-0">
                <div className="space-y-2">
                  {[1, 2, 3, 4, 5].map((file) => (
                    <motion.div
                      key={file}
                      whileHover={{ x: 3 }}
                      className="flex items-center gap-3 p-2 rounded-md hover:bg-cyan-950/30 transition-colors"
                    >
                      <div className="h-8 w-8 rounded-md bg-cyan-900/30 flex items-center justify-center">
                        <FileText className="h-4 w-4 text-cyan-400" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-cyan-300 truncate">Project Documentation {file}.pdf</p>
                        <p className="text-xs text-cyan-400/70">Updated 2 days ago</p>
                      </div>
                      <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </motion.div>
                  ))}
                </div>
                <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  <Plus className="mr-2 h-4 w-4" />
                  Upload File
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Task Summary */}
      <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-cyan-300">Task Summary</CardTitle>
            <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
              <Plus className="h-4 w-4 mr-1" />
              Add Task
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-cyan-300 flex items-center gap-1">
                <CheckCircle2 className="h-4 w-4 text-green-400" />
                Completed
              </h3>
              <div className="space-y-2">
                {[1, 2, 3].map((task) => (
                  <div key={task} className="p-2 rounded-md bg-green-900/10 border border-green-900/30 text-cyan-300 text-sm">
                    Update AI model parameters
                  </div>
                ))}
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-cyan-300 flex items-center gap-1">
                <Circle className="h-4 w-4 text-cyan-400" />
                In Progress
              </h3>
              <div className="space-y-2">
                {[1, 2, 3, 4].map((task) => (
                  <div key={task} className="p-2 rounded-md bg-cyan-900/10 border border-cyan-900/30 text-cyan-300 text-sm">
                    Optimize data pipeline for better throughput
                  </div>
                ))}
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-cyan-300 flex items-center gap-1">
                <AlertCircle className="h-4 w-4 text-yellow-400" />
                Pending
              </h3>
              <div className="space-y-2">
                {[1, 2].map((task) => (
                  <div key={task} className="p-2 rounded-md bg-yellow-900/10 border border-yellow-900/30 text-cyan-300 text-sm">
                    Prepare presentation for client meeting
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

