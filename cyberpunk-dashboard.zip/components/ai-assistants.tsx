"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Brain, Zap, Play, Pause, RefreshCw, Plus, Settings, ChevronRight, MessageSquare, Code, Image, FileText } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function AIAssistants() {
  const [activeModel, setActiveModel] = useState("gpt-4");
  const [isRunning, setIsRunning] = useState(true);
  
  const aiModels = [
    { 
      id: "gpt-4", 
      name: "GPT-4 Turbo", 
      description: "Advanced language model", 
      status: "Active", 
      usage: 78,
      type: "text",
      icon: <MessageSquare className="h-5 w-5 text-cyan-400" />
    },
    { 
      id: "dalle-3", 
      name: "DALL-E 3", 
      description: "Image generation model", 
      status: "Active", 
      usage: 62,
      type: "image",
      icon: <Image className="h-5 w-5 text-purple-400" />
    },
    { 
      id: "codex", 
      name: "Codex", 
      description: "Code generation assistant", 
      status: "Inactive", 
      usage: 0,
      type: "code",
      icon: <Code className="h-5 w-5 text-green-400" />
    },
  ];

  const modelDetails = {
    "gpt-4": {
      capabilities: ["Natural language processing", "Content generation", "Summarization", "Translation"],
      parameters: "175 billion",
      latency: "~500ms",
      accuracy: "98.7%"
    },
    "dalle-3": {
      capabilities: ["Image generation", "Style transfer", "Visual editing", "Concept visualization"],
      parameters: "12 billion",
      latency: "~2s",
      accuracy: "96.2%"
    },
    "codex": {
      capabilities: ["Code generation", "Bug fixing", "Code translation", "Documentation"],
      parameters: "12 billion",
      latency: "~300ms",
      accuracy: "94.5%"
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">AI Assistants</h2>
        <Button className="bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
          <Plus className="mr-2 h-4 w-4" />
          Deploy New Model
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* AI Models List */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-cyan-300">Available Models</h3>
          
          {aiModels.map((model) => (
            <motion.div
              key={model.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Card 
                className={`border-cyan-900/50 ${activeModel === model.id ? 'bg-cyan-900/30' : 'bg-black/30'} backdrop-blur-sm cursor-pointer`}
                onClick={() => setActiveModel(model.id)}
              >
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-cyan-900/30 flex items-center justify-center">
                        {model.icon}
                      </div>
                      <div>
                        <CardTitle className="text-cyan-300 text-base">{model.name}</CardTitle>
                        <CardDescription className="text-cyan-400/70 text-xs">{model.description}</CardDescription>
                      </div>
                    </div>
                    <ChevronRight className={`h-5 w-5 text-cyan-400 transition-transform ${activeModel === model.id ? 'rotate-90' : ''}`} />
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex justify-between text-xs text-cyan-400/70 mb-1">
                    <span>Usage</span>
                    <span className={model.status === "Active" ? "text-green-400" : "text-yellow-400"}>
                      {model.status}
                    </span>
                  </div>
                  <Progress 
                    value={model.usage} 
                    className="h-1 bg-cyan-950" 
                    indicatorClassName={`bg-gradient-to-r ${
                      model.type === "text" ? "from-cyan-400 to-blue-400" : 
                      model.type === "image" ? "from-purple-400 to-pink-400" : 
                      "from-green-400 to-emerald-400"
                    }`} 
                  />
                </CardContent>
              </Card>
            </motion.div>
          ))}
          
          <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
            View All Models
          </Button>
        </div>

        {/* Model Details and Interaction */}
        <div className="col-span-2 space-y-4">
          <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-cyan-300">
                    {aiModels.find(m => m.id === activeModel)?.name}
                  </CardTitle>
                  <CardDescription className="text-cyan-400/70">
                    {aiModels.find(m => m.id === activeModel)?.description}
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50"
                    onClick={() => setIsRunning(!isRunning)}
                  >
                    {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50"
                  >
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="space-y-1">
                  <p className="text-xs text-cyan-400/70">Parameters</p>
                  <p className="text-sm text-yellow-400">{modelDetails[activeModel as keyof typeof modelDetails].parameters}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-cyan-400/70">Latency</p>
                  <p className="text-sm text-yellow-400">{modelDetails[activeModel as keyof typeof modelDetails].latency}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-cyan-400/70">Status</p>
                  <p className="text-sm text-green-400">{isRunning ? "Running" : "Paused"}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-cyan-400/70">Accuracy</p>
                  <p className="text-sm text-yellow-400">{modelDetails[activeModel as keyof typeof modelDetails].accuracy}</p>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <p className="text-sm text-cyan-300">Capabilities</p>
                <div className="flex flex-wrap gap-2">
                  {modelDetails[activeModel as keyof typeof modelDetails].capabilities.map((capability, index) => (
                    <div 
                      key={index} 
                      className="px-2 py-1 rounded-md text-xs bg-cyan-900/30 text-cyan-300 border border-cyan-800/50"
                    >
                      {capability}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-cyan-300">Interact with Model</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="prompt">
                <TabsList className="bg-cyan-950/30 border border-cyan-900/50">
                  <TabsTrigger value="prompt" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                    Prompt
                  </TabsTrigger>
                  <TabsTrigger value="settings" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                    Settings
                  </TabsTrigger>
                  <TabsTrigger value="history" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                    History
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="prompt" className="mt-4 space-y-4">
                  <Textarea 
                    placeholder="Enter your prompt here..." 
                    className="min-h-32 bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300 placeholder:text-cyan-700"
                  />
                  <div className="flex justify-between">
                    <Button variant="outline" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                      <FileText className="mr-2 h-4 w-4" />
                      Load Template
                    </Button>
                    <Button className="bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
                      <Zap className="mr-2 h-4 w-4" />
                      Execute
                    </Button>
                  </div>
                </TabsContent>
                
                <TabsContent value="settings" className="mt-4 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm text-cyan-300">Temperature</label>
                      <Input 
                        type="number" 
                        defaultValue="0.7" 
                        min="0" 
                        max="1" 
                        step="0.1" 
                        className="bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-cyan-300">Max Tokens</label>
                      <Input 
                        type="number" 
                        defaultValue="2048" 
                        min="1" 
                        max="4096" 
                        className="bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-cyan-300">Top P</label>
                      <Input 
                        type="number" 
                        defaultValue="0.9" 
                        min="0" 
                        max="1" 
                        step="0.1" 
                        className="bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-cyan-300">Frequency Penalty</label>
                      <Input 
                        type="number" 
                        defaultValue="0.5" 
                        min="0" 
                        max="2" 
                        step="0.1" 
                        className="bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300"
                      />
                    </div>
                  </div>
                  <Button className="w-full bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
                    Save Settings
                  </Button>
                </TabsContent>
                
                <TabsContent value="history" className="mt-4 space-y-4">
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {[1, 2, 3, 4, 5].map((item) => (
                      <div key={item} className="p-3 rounded-md bg-cyan-950/20 border border-cyan-900/50">
                        <div className="flex justify-between items-center mb-1">
                          <p className="text-xs text-cyan-400/70">{new Date().toLocaleString()}</p>
                          <Button variant="ghost" size="sm" className="h-6 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Rerun
                          </Button>
                        </div>
                        <p className="text-sm text-cyan-300 truncate">Generate a summary of the quarterly financial report...</p>
                      </div>
                    ))}
                  </div>
                  <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                    Clear History
                  </Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

