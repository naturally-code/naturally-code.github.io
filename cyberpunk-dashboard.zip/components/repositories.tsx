"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { FolderGit2, GitBranch, GitCommit, GitPullRequest, Search, Filter, Plus, Clock, Code, Eye, Star, GitFork, ChevronRight, AlertCircle, CheckCircle2, XCircle, GitMerge } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Repositories() {
  const [searchQuery, setSearchQuery] = useState("");
  
  const repositories = [
    { 
      id: 1, 
      name: "ai-model-framework", 
      description: "Framework for training and deploying AI models", 
      language: "Python",
      stars: 245,
      forks: 87,
      updated: "2 days ago",
      issues: 12,
      pullRequests: 5
    },
    { 
      id: 2, 
      name: "data-pipeline", 
      description: "ETL pipeline for processing large datasets", 
      language: "Python",
      stars: 132,
      forks: 45,
      updated: "1 week ago",
      issues: 8,
      pullRequests: 3
    },
    { 
      id: 3, 
      name: "dashboard-ui", 
      description: "React components for data visualization dashboards", 
      language: "TypeScript",
      stars: 189,
      forks: 63,
      updated: "3 days ago",
      issues: 15,
      pullRequests: 7
    },
    { 
      id: 4, 
      name: "api-service", 
      description: "RESTful API service for data access", 
      language: "JavaScript",
      stars: 98,
      forks: 32,
      updated: "5 days ago",
      issues: 6,
      pullRequests: 2
    },
  ];

  const filteredRepos = repositories.filter(repo => 
    repo.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    repo.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    repo.language.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const recentCommits = [
    { 
      id: 1, 
      message: "Fix model training pipeline", 
      repo: "ai-model-framework", 
      author: "Alex Smith",
      avatar: "AS",
      time: "2 hours ago",
      hash: "a1b2c3d"
    },
    { 
      id: 2, 
      message: "Update README with installation instructions", 
      repo: "data-pipeline", 
      author: "Jane Doe",
      avatar: "JD",
      time: "5 hours ago",
      hash: "e4f5g6h"
    },
    { 
      id: 3, 
      message: "Add new visualization component", 
      repo: "dashboard-ui", 
      author: "Mike Kim",
      avatar: "MK",
      time: "1 day ago",
      hash: "i7j8k9l"
    },
  ];

  const pullRequests = [
    { 
      id: 1, 
      title: "Implement new feature detection algorithm", 
      repo: "ai-model-framework", 
      author: "Jane Doe",
      avatar: "JD",
      status: "Open",
      time: "1 day ago"
    },
    { 
      id: 2, 
      title: "Fix memory leak in data processor", 
      repo: "data-pipeline", 
      author: "Alex Smith",
      avatar: "AS",
      status: "Review",
      time: "2 days ago"
    },
    { 
      id: 3, 
      title: "Add dark mode support", 
      repo: "dashboard-ui", 
      author: "Tom Wilson",
      avatar: "TW",
      status: "Merged",
      time: "3 days ago"
    },
    { 
      id: 4, 
      title: "Optimize API response time", 
      repo: "api-service", 
      author: "Mike Kim",
      avatar: "MK",
      status: "Closed",
      time: "1 week ago"
    },
  ];

  const languageColors: Record<string, string> = {
    "Python": "bg-blue-400",
    "TypeScript": "bg-blue-500",
    "JavaScript": "bg-yellow-400",
    "Java": "bg-red-400",
    "Go": "bg-cyan-400",
    "Rust": "bg-orange-400",
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-cyan-400">Repositories</h2>
        <Button className="bg-gradient-to-r from-cyan-600 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 text-white">
          <Plus className="mr-2 h-4 w-4" />
          New Repository
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Stats Cards */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Repositories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <FolderGit2 className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">32</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Pull Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <GitPullRequest className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">17</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Commits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <GitCommit className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">1,243</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-cyan-300 text-lg">Branches</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="h-12 w-12 rounded-full bg-cyan-900/30 flex items-center justify-center">
                <GitBranch className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="text-3xl font-bold text-cyan-300">78</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Repositories List */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm col-span-2">
          <CardHeader>
            <CardTitle className="text-cyan-300">Your Repositories</CardTitle>
            <CardDescription className="text-cyan-400/70">Browse and manage your code repositories</CardDescription>
            
            <div className="flex flex-col sm:flex-row gap-4 mt-4">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-cyan-400/70" />
                <Input 
                  placeholder="Search repositories..." 
                  className="pl-8 bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300 placeholder:text-cyan-700"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Select defaultValue="all">
                  <SelectTrigger className="w-[130px] bg-cyan-950/20 border-cyan-900/50 focus:border-cyan-700 text-cyan-300">
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent className="bg-cyan-950 border-cyan-900 text-cyan-300">
                    <SelectItem value="all">All Languages</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="typescript">TypeScript</SelectItem>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredRepos.map((repo) => (
                <motion.div
                  key={repo.id}
                  whileHover={{ y: -2 }}
                  className="p-4 rounded-md border border-cyan-900/50 bg-cyan-950/20 hover:bg-cyan-950/30 transition-colors"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-cyan-300 flex items-center gap-2">
                        <FolderGit2 className="h-4 w-4 text-yellow-400" />
                        {repo.name}
                      </h3>
                      <p className="text-sm text-cyan-400/70 mt-1">{repo.description}</p>
                    </div>
                    <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-4 mt-4">
                    <div className="flex items-center gap-1">
                      <div className={`h-3 w-3 rounded-full ${languageColors[repo.language] || 'bg-gray-400'}`} />
                      <span className="text-xs text-cyan-400">{repo.language}</span>
                    </div>
                    
                    <div className="flex items-center gap-1 text-xs text-cyan-400">
                      <Star className="h-3 w-3" />
                      {repo.stars}
                    </div>
                    
                    <div className="flex items-center gap-1 text-xs text-cyan-400">
                      <GitFork className="h-3 w-3" />
                      {repo.forks}
                    </div>
                    
                    <div className="flex items-center gap-1 text-xs text-cyan-400">
                      <AlertCircle className="h-3 w-3" />
                      {repo.issues} issues
                    </div>
                    
                    <div className="flex items-center gap-1 text-xs text-cyan-400">
                      <GitPullRequest className="h-3 w-3" />
                      {repo.pullRequests} PRs
                    </div>
                    
                    <div className="flex items-center gap-1 text-xs text-cyan-400 ml-auto">
                      <Clock className="h-3 w-3" />
                      Updated {repo.updated}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="text-sm text-cyan-400">
              Showing <span className="text-yellow-400">{filteredRepos.length}</span> of <span className="text-yellow-400">{repositories.length}</span> repositories
            </div>
            <Button variant="outline" className="border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
              View All
            </Button>
          </CardFooter>
        </Card>

        {/* Activity */}
        <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-cyan-300">Activity</CardTitle>
            <CardDescription className="text-cyan-400/70">Recent commits and pull requests</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue="commits" className="h-full">
              <TabsList className="mx-4 bg-cyan-950/30 border border-cyan-900/50">
                <TabsTrigger value="commits" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                  Commits
                </TabsTrigger>
                <TabsTrigger value="prs" className="data-[state=active]:bg-cyan-900/50 data-[state=active]:text-cyan-300">
                  Pull Requests
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="commits" className="p-4 space-y-4 m-0">
                {recentCommits.map((commit) => (
                  <div key={commit.id} className="flex items-start gap-3 p-2 rounded-md hover:bg-cyan-950/20 transition-colors">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-cyan-900/70 text-cyan-300">
                        {commit.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm text-cyan-300 font-medium truncate">{commit.message}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className="bg-cyan-900/30 text-cyan-300 border border-cyan-800/50">
                          {commit.repo}
                        </Badge>
                        <span className="text-xs text-yellow-400 font-mono">{commit.hash}</span>
                      </div>
                      <p className="text-xs text-cyan-400/70 flex items-center gap-1 mt-1">
                        <Clock className="h-3 w-3" /> {commit.time} by {commit.author}
                      </p>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  View All Commits
                </Button>
              </TabsContent>
              
              <TabsContent value="prs" className="p-4 space-y-4 m-0">
                {pullRequests.map((pr) => (
                  <div key={pr.id} className="flex items-start gap-3 p-2 rounded-md hover:bg-cyan-950/20 transition-colors">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-cyan-900/70 text-cyan-300">
                        {pr.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm text-cyan-300 font-medium truncate">{pr.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className="bg-cyan-900/30 text-cyan-300 border border-cyan-800/50">
                          {pr.repo}
                        </Badge>
                        <div className={`px-1.5 py-0.5 text-xs rounded-full flex items-center gap-1
                          ${pr.status === 'Open' ? 'bg-green-900/30 text-green-300' : 
                            pr.status === 'Review' ? 'bg-yellow-900/30 text-yellow-300' : 
                            pr.status === 'Merged' ? 'bg-purple-900/30 text-purple-300' : 
                            'bg-red-900/30 text-red-300'}`}
                        >
                          {pr.status === 'Open' && <CheckCircle2 className="h-3 w-3" />}
                          {pr.status === 'Review' && <AlertCircle className="h-3 w-3" />}
                          {pr.status === 'Merged' && <GitMerge className="h-3 w-3" />}
                          {pr.status === 'Closed' && <XCircle className="h-3 w-3" />}
                          {pr.status}
                        </div>
                      </div>
                      <p className="text-xs text-cyan-400/70 flex items-center gap-1 mt-1">
                        <Clock className="h-3 w-3" /> {pr.time} by {pr.author}
                      </p>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full border-cyan-700 text-cyan-400 hover:bg-cyan-950/50">
                  View All Pull Requests
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Popular Repositories */}
      <Card className="border-cyan-900/50 bg-black/30 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-cyan-300">Popular Repositories</CardTitle>
            <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-950/30">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {repositories.map((repo) => (
              <motion.div
                key={repo.id}
                whileHover={{ y: -3, scale: 1.02 }}
                className="p-3 rounded-md border border-cyan-900/50 bg-cyan-950/20 hover:bg-cyan-950/30 transition-colors"
              >
                <h3 className="font-medium text-cyan-300 truncate">{repo.name}</h3>
                <p className="text-xs text-cyan-400/70 mt-1 h-8 overflow-hidden">{repo.description}</p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex items-center gap-1">
                    <div className={`h-2 w-2 rounded-full ${languageColors[repo.language] || 'bg-gray-400'}`} />
                    <span className="text-xs text-cyan-400">{repo.language}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-cyan-400">
                    <Star className="h-3 w-3" />
                    {repo.stars}
                  </div>
                  <div className="flex items-center gap-1 text-xs text-cyan-400">
                    <GitFork className="h-3 w-3" />
                    {repo.forks}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

